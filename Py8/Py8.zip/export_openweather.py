
""" OpenWeatherMap (экспорт)

Сделать скрипт, экспортирующий данные из базы данных погоды, 
созданной скриптом openweather.py. Экспорт происходит в формате CSV или JSON.

Скрипт запускается из командной строки и получает на входе:
    export_openweather.py --csv filename [<город>]
    export_openweather.py --json filename [<город>]
    export_openweather.py --html filename [<город>]
    
При выгрузке в html можно по коду погоды (weather.id) подтянуть 
соответствующие картинки отсюда:  http://openweathermap.org/weather-conditions

Экспорт происходит в файл filename.

Опционально можно задать в командной строке город. В этом случае 
экспортируются только данные по указанному городу. Если города нет в базе -
выводится соответствующее сообщение.

"""


from dominate import document
from dominate.tags import *
import urllib.request
import sys
import sqlite3


db_filename = 'db_weather.sqlite'
print(sys.argv)
try:
    filename = sys.argv[1]
    city = sys.argv[2]
except IndexError:
    print("Задан неверный параметр")





with sqlite3.connect(db_filename) as conn:
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute('''
        select distinct id_города, Город, Страна, Дата, Температура, id_погоды, Значок
        from weather
        where Город = ?''', (city,))
    one_row = cur.fetchone()
    if one_row:
        print(one_row)
        print(list(one_row))
        with document(title='Weather') as doc:
            h1('Weather')

            with table().add(tbody()):
                table_header = tr()
                for i in ('id_города', 'Город', 'Страна', 'Дата', 'Температура', 'id_погоды', 'Значок'):
                    table_header(th(i))

                next_row = tr()
                for k in one_row:
                    if k == one_row[-1]:
                       path = "http://openweathermap.org/img/w/" + k + ".png"
                       next_row.add(td(img(src=path)))
                    else:
                       next_row.add(td(k))

        with open(filename, 'w') as f:
            f.write(doc.render())

    else:
        print("Город отсутствует в базе")





